<html>
    <head>

        <title></title>
        <link rel="stylesheet" href="style_masrofat.css">
        <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
      />
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

      <style>
        
        
          

        .div
        {
            width: 55;
            
 background-color: black;
        height: 50px;
        display: inline-block;
        border-radius: 0px 10px 10px;
        box-shadow:20px 20px 40px gray;
            height: 50px;
            display: inline-block;
            border-radius: 0px 30px 30px 0px;
            box-shadow:2px 2px 2px gray;
            margin-left: 172px;
            position: absolute;
            margin-top: 13px;
            padding-right: 15px;
            border: 1px solid black;

            
        }
        .h1 
        {
            color:white;
            font-size: 25px;
            margin-left: 25%;
            margin-top: 8px;
            padding: 5px;
            
            
        }
        .div2
        {
            width: 55;
            background-color:orange;
            height: 50px;
            display: inline-block;
            border-radius: 0px 30px 30px 0px;
            box-shadow:2px 2px 2px gray;
            margin-left: 172px;
            position: absolute;
            margin-top: 77px;
            padding-right: 15px;
            border: 1px solid orange;
            
            display: none;
        
        }
        .h1 
        {
            color:white;
            font-size: 25px;
            margin-left: 25%;
            margin-top: 8px;
            padding: 5px;
            
            
        }







        <!----->

         .div
        {
            width: 55;
            background-color:black;
            height: 50px;
            display: inline-block;
            border-radius: 0px 30px 30px 0px;
            box-shadow:2px 2px 2px gray;
            margin-left: 172px;
            position: absolute;
            margin-top: 13px;
            padding-right: 15px;
            border: 1px solid black;
            display: none;
        
        }
        .h1 
        {
            color:white;
            font-size: 25px;
            margin-left: 25%;
            margin-top: 8px;
            padding: 5px;
            
            
        }
        .div2
        {
            width: 55;
            background-color:orange;
            height: 50px;
            display: inline-block;
            border-radius: 0px 30px 30px 0px;
            box-shadow:2px 2px 2px gray;
            margin-left: 172px;
            position: absolute;
            margin-top: 77px;
            padding-right: 15px;
            border: 1px solid orange;
            
         
        
        }

       





        .bnin
        {
          width: 55;
            background-color:orange;
            height: 50px;
            display: inline-block;
            border-radius: 0px 30px 30px 0px;
            box-shadow:2px 2px 2px gray;
            right: 10px;
            position: absolute;
            margin-top: 356px;
            padding-right: 15px;
            border: 1px solid orange;
           
        }
        .bnat
        {
          width: 55;
            background-color:black;
            height: 50px;
            display: inline-block;
            border-radius: 0px 30px 30px 0px;
            box-shadow:2px 2px 2px gray;
            right: 10px;
            position: absolute;
            margin-top:290px;
           
            padding-right: 15px;
            border: 1px solid black;
           
        }




        .bnin2
        {
          width: 55;
            background-color:orange;
            height: 50px;
            display: inline-block;
            border-radius: 0px 30px 30px 0px;
            box-shadow:2px 2px 2px gray;
            margin-left: 170PX;
            position: absolute;
            margin-top: 13px;
            padding-right: 15px;
            border: 1px solid orange;
           
        }
        .bnat2
        {
          width: 55;
            background-color:black;
            height: 50px;
            display: inline-block;
            border-radius: 0px 30px 30px 0px;
            box-shadow:2px 2px 2px gray;
            margin-left: 170PX;
            position: absolute;
            margin-top:77px;
            padding-right: 15px;
           
            border: 1px solid black;
           
        }
        .maaindiv
        {
          margin-top: 280px;
          display: inline-block;
          position: absolute;
        }


        .bnin4
        {
          width: 55;
            background-color:orange;
            height: 50px;
            display: inline-block;
            border-radius: 0px 30px 30px 0px;
            box-shadow:2px 2px 2px gray;
           margin-left: -300px;
            position: absolute;
            margin-top: 57px;
            padding-right: 15px;
            border: 1px solid orange;
           
        }
.bnat4{
        width: 55;
            background-color:black;
            height: 50px;
            display: inline-block;
            border-radius: 0px 30px 30px 0px;
            box-shadow:2px 2px 2px gray;
            margin-left: -300PX;
            position: absolute;
            margin-top:127px;
            padding-right: 15px;
           
            border: 1px solid black;
           
}















@media all and (min-width: 1002px) and  (max-width: 1400px) {
 
 .quotes .box1 {
     
   width: 23vw;
   height: 10vh;
    
   }
.bnattalta
{
 margin-left:-20px
}
.bnattalta .h1
{
 margin-left:185px
}
   
   .bnattalta2
{
 margin-left:-20px
}
.bnattalta2 .h1
{
 margin-left:185px
}



.quotes .box2 {
     
     width: 23vw;
     height: 10vh;
     margin-left:-171px
     }
.div 
{
 margin-left:142px
}
.div2 
{
 margin-left:142px
}
.quotes .box3 {
     
     width: 23vw;
     height: 10vh;
     margin-left:-171px
     }
     .quotes .box h1
     {
       margin-left:10px
     }





   .box4 {
     
     width: 23vw;
     height: 10vh;
     margin-left:-648px
     }
     .bnin4 
     {
       margin-left: -334px;
   margin-top: 67px;
     }
     .bnat4 
     {
       margin-left: -334px;
   margin-top: 133px;
     }


     .box5 {
     
     width: 23vw;
     height: 10vh;
   
     }
     .bnin2
     {
       margin-left: 131px;
     }
     .bnat2
     {
       margin-left: 131px;
     }


     .box6 {
     
     width: 23vw;
     height: 10vh;
     margin-left: 284px;
     }

   }


































































   









































































@media all and (min-width: 300px) and  (max-width: 1000px) {
 
 .quotes .box1 {
     
     width:690px;
     height:400px;
     margin-top:-600px;
     margin-left:-100px;
   }
   .div
   {
     margin-left:590px;
     margin-top:-580px;
     height:100px;
      width:180px;
   }
   .div2
   {
     margin-left:590px;
     margin-top:-450px;
      height:100px;  width:180px;
   }
        .quotes .box1 h1
     {
       font-size:50px;
     }
         .div .h1
   {
    font-size:50px;
     
   }
      .div2 .h1
   {
    font-size:50px;
     
   }








   .quotes .box2 {
     
     width:690px;
     height:400px;
     margin-top:-100px;
     margin-left:-100px;
   }
   .bnat2
   {
     margin-left:590px;
     margin-top:-580px;
     height:100px;
      width:180px;
   }
   .bnin2
   {
     margin-left:590px;
     margin-top:-450px;
      height:100px;  width:180px;
   }
        .quotes .box1 h1
     {
       font-size:50px;
     }
     .bnin2 .h1 
   {
    font-size:50px;
     
   }
.h1
   {
    font-size:50px;
     
   }
   .maaindiv
   {
     margin-top:510px;
   }
















   .quotes .box h1
   {
     font-size:50px;
   }
   .quotes .box3 {
     
     width: 690px;
   height: 400px;
   margin-top: 424px;
   margin-left: -879px;
   position: absolute;
   }
   .bnat 
   {    margin-left: 590px;
   margin-top: 456px;
   height: 100px;
   width: 180px;
   left: 147px;
   }
  h1  
   {
     font-size:50px;
   }
   .bnin
   {
     margin-left: 497px;
   margin-top: 596px;
   height: 100px;
   width: 180px;
   left: 744px;
   left: 246px;
   }
  


















   .box4 {
   width: 690px;
   height: 400px;
   margin-top: 648px;
   margin-left: -421px;
   }
   .bnat4 
   {    margin-left: 590px;
   margin-top: 682px;
   height: 100px;
   width: 180px;
   left: 147px;
   }
   .box4 h4 
   {
     font-size:50px;
   }
   .bnin4
   {
     margin-left: 497px;
   margin-top: 819px;
   height: 100px;
   width: 180px;
   left: 744px;
   left: 246px;
   }


















   .box5 {
   width: 690px;
   height: 400px;
   margin-top: 1172px;
   margin-left: -421px;
   }
   .bnat5
   {    margin-left: 590px;
   margin-top: 682px;
   height: 100px;
   width: 180px;
   left: 147px;
   }
   .box5 h5
   {
     font-size:50px;
   }
   .bnin5
   {
     margin-left: 497px;
   margin-top: 1019px;
   height: 100px;
   width: 180px;
   left: 744px;
   left: 246px;
   }
   .tanias
   {
     margin-top:200px;
     margin-top: 2099px;
   margin-left: -757px;
   position: absolute;
   }
   .tanias2
   {
     margin-top:200px;
     margin-top: 1909px;
   margin-left: -757px;
   position: absolute;
   }



































   .box6 {
   width: 690px;
   height: 400px;
   margin-top: 1705px;
   margin-left: -421px;
   }


   .taniasb
   {
     width:1000px;
     background:red;
   }


   .bnattalta
   {
  
     background-color: orange;
   display: inline-block;
   border-radius: 0px 30px 30px 0px;
   box-shadow: 2px 2px 2px orange;
   margin-left: 590PX;
   position: absolute;
   margin-top: 2170px;
   padding-right: 15px;
   height: 100px;
   width: 180px;
   border: 1px solid orange;
   }

   .bnattalta2
   {
  
     background-color: black;
   display: inline-block;
   border-radius: 0px 30px 30px 0px;
   box-shadow: 2px 2px 2px black;
   margin-left: 590PX;
   position: absolute;
   margin-top: 2042px;
   padding-right: 15px;
   height: 100px;
   width: 180px;
   border: 1px solid black;
   }
   h1 
   {
     font-size:50px;
   }
   .bnattalta2 div
   {
     display:;
   }
   .bnattalta2  .h1
   {
     margin-top: 18px;
   position: absolute;    background-color: black;
   margin-left: 69px;  border:2px solid black;
   }
   .bnattalta  .h1
   {
     margin-top: 18px;
   position: absolute;    background-color: orange;
   margin-left: 69px; border:2px solid orange;
   }
   
   .bnattalta div
   {
     position: absolute;
   }
}
            </style>
    </head>
    <body>
    
        <div class="quotes">
       
          <div class="card">
          <a href="http://localhost/projecttt/fees/index.php">
            <div class="div" >
                <h1 class="h1">بنين</h1>
            </div>
            </a>
            <a href="http://localhost/projecttt/fees2/index.php">   <div class="div2" >
                <h1 class="h1">بنات</h1>
            </div>
</a>
            <div class="box box1">
              <h1>الصف الاول الاعدادي </h1>
              <h2> 1</h2>
            </div>
            <div class="bg"></div>
          </div>



          <div class="card">
          <a href="http://localhost/projecttt/fees3/index.php">
            <div class="div" >
              <h1 class="h1">بنين</h1>
          </div>
</a>
<a href="http://localhost/projecttt/fees4/index.php">  <div class="div2" >
              <h1 class="h1">بنات</h1>
          </div>
</a>
            <div class="maaindiv">
            <a href="http://localhost/projecttt/fees9/index.php">
            <div class="bnin2" >
              <h1 class="h1">بنات</h1>
          </div>
</a>
<a href="http://localhost/projecttt/fees10/index.php">
          <div class="bnat2" >
            <h1 class="h1">بنين</h1>
        </div>
</a>
      </div>
            <div class="box box2">
              <h1>الصف الثاني الاعدادي</h1>
              <h2> 2</h2>
            </div>
            <div class="bg"></div>
          </div>
          <div class="card">  <a href="http://localhost/projecttt/fees5/index.php"> <div class="div" >
                <h1 class="h1">بنين</h1>
            </div>
</a>
<a href="http://localhost/projecttt/fees6/index.php">   <div class="div2" >
                <h1 class="h1">بنات</h1>
            </div></a>
            <a href="http://localhost/projecttt/fees12/index.php">
            <div class="bnin" >
                <h1 class="h1">بنات</h1>
            </div>
</a>
<a href="http://localhost/projecttt/fees11/index.php">
            <div class="bnat" >
              <h1 class="h1">بنين</h1>
          </div>
</a>
            <div class="box box3">
              <h1>الصف الثالث الاعدادي </h1>
              <h2>3</h2>
            </div>
            <div class="bg"></div>
          </div>

         
          </div>
          <div class="card">
          <a href="http://localhost/projecttt/fees7/index.php">
            <div class="bnin4" >
              <h1 class="h1">بنات</h1>
          </div>
</a>
<a href="http://localhost/projecttt/fees8/index.php">  
          <div class="bnat4" >
            <h1 class="h1">بنين</h1>
        </div>
</a>
            <div class="box box4">
              <h1>الصف الاول الثانوي </h1>
              <h2>4</h2>
            </div>
            <div class="bg"></div>



            <div class="card">
                
                <div class="box box5">
                  <h1>الصف الثاني الثانوي </h1>
                  <h2>5</h2>
                </div>
                <div class="bg"></div>
        </div>

       <div class="card">
                <div class="box box6">
                  <h1>الصف الثالث الثانوي </h1>
                  <h2>6</h2>
                </div>
                <div class="bg"></div>
        </div>




        <!----jquey ya sa7py-->
   
       
    </body>
</html>
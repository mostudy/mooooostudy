

<html></html>
<head>
    <link rel="stylesheet" href="att.css">



    <style>

.wrapper {
    padding: 1.5rem 0;
    filter: url('#goo');
}

.button {
    display: inline-block;
    text-align: center;
    background: #28a745;
    color: white;
    font-weight: bold;
    padding: 20px;
    line-height: 1;
    border-radius: 1em;
    position: absolute;
    min-width: 80px;
    text-decoration: none;
    font-family: var(--font);
    font-size: 1.25rem;
}

.button:before,
.button:after {
    width: 4.4em;
    height: 2.95em;
    position: absolute;
    content: "";
    display: inline-block;
    background: #28a745;
    border-radius: 50%;
    transition: transform 1s ease;
    transform: scale(0);
    z-index: -1;
}

.button:before {
    top: -25%;
    left: 20%;
}

.button:after {
    bottom: -25%;
    right: 20%;
}

.button:hover:before,
.button:hover:after {
    transform: none;
}


/* Demo styles */


</style>
</head>
<body>
<!-- Inspiration: https://dribbble.com/shots/4397812-Click-Me -->
<div class="wrapper">
    <a href="http://localhost/projecttt/home.php" class="button" href="#">رجوع</a>
</div>

<!-- Filter: https://css-tricks.com/gooey-effect/ -->
<svg style="visibility: hidden; position: absolute;" width="0" height="0" xmlns="http://www.w3.org/2000/svg" version="1.1">
    <defs>
        <filter id="goo"><feGaussianBlur in="SourceGraphic" stdDeviation="10" result="blur" />    
            <feColorMatrix in="blur" mode="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 19 -9" result="goo" />
            <feComposite in="SourceGraphic" in2="goo" operator="atop"/>
        </filter>
    </defs>
</svg>

    <h1>اختار نوع التسجيل</h1>
    <div class="container">
    <a href="http://localhost/projecttt/student-attendance-system-in-php-using-ajax/admin/login.php" > <div class="product">
        <div class="effect-1"></div>
        <div class="effect-2"></div>
        <div class="content">
          <div class="exercise">1</div>
        </div>
    </a>
        <span class="title">
          تسجيل الي تقارير الصفوف
         
        </span>
      </div>
    
      <a href="http://localhost/projecttt/student-attendance-system-in-php-using-ajax/login.php" >   <div class="product">
        <div class="effect-1"></div>
        <div class="effect-2"></div>
        <div class="content">
          <div class="sleep">2</div>
        </div></a>
        <span class="title">
          تسجيل كمعلم 
         
        </span>
     
</body>
</html>
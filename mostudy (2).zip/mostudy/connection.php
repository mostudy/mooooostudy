<?php
$server_name = "localhost";
$db_user = "root";
$db_password = "";
$db_name = "login";

$conn = new mysqli($server_name, $db_user, $db_password, $db_name);
